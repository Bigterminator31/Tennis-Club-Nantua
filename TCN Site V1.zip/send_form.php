<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$destinataire = "mougellucas01@gmail.com";
$sujet = "Nouvelle demande d'adhésion depuis le site du Tennis Club de Nantua";

function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$nom = sanitize($_POST['nom'] ?? '');
$naissance = sanitize($_POST['naissance'] ?? '');
$adresse = sanitize($_POST['adresse'] ?? '');
$telephone = sanitize($_POST['telephone'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$categorie = sanitize($_POST['categorie'] ?? '');
$droit_image = isset($_POST['droit_image']) ? "Oui" : "Non";

if (!$nom || !$email || !$telephone || !$categorie) {
    echo "<p style='color:red;font-weight:bold;'>❌ Merci de remplir tous les champs obligatoires.</p>";
    exit;
}

$message = "
Nouvelle demande d'adhesion reçue via le site web :

Nom et prénom : $nom
Date de naissance : $naissance
Adresse : $adresse
Téléphone : $telephone
Email : $email
Catégorie : $categorie
Droit à l'image : $droit_image
";

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'tennisclubnantua@gmail.com';
    $mail->Password   = 'zkoe gckq khti wnif';
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('mougellucas01@gmail.com', 'Tennis Club Nantua');
    $mail->addAddress($destinataire);
    $mail->addReplyTo($email);

    $mail->isHTML(false);
    $mail->Subject = $sujet;
    $mail->Body    = $message;

    $mail->send();
    echo "<p style='color:green;font-weight:bold;'>✅ Formulaire bien envoyé !</p>";

} catch (Exception $e) {
    echo "<p style='color:red;font-weight:bold;'>❌ Erreur lors de l'envoi du formulaire : {$mail->ErrorInfo}</p>";
}
?>

