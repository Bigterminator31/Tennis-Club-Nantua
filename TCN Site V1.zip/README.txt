
Tennis Club de Nantua — Site web statique
Fichiers inclus :
- index.html, club.html, ecole.html, equipes.html, adhesion.html,
  calendrier.html, galerie.html, contact.html, mentions.html, partenaires.html
- css/style.css
- js/main.js
- assets/

Instructions :
Déposez le dossier 'tennis_club_nantua_site' dans le répertoire www de votre serveur (ex: WampServer -> www).
