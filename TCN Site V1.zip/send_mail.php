<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

header('Content-Type: text/html; charset=utf-8');

$destinataire = "mougellucas01@gmail.com";

function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$name = sanitize($_POST['name'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$subject = sanitize($_POST['subject'] ?? '');
$message_content = sanitize($_POST['message'] ?? '');

if (!$name || !$email || !$subject || !$message_content) {
    echo "<p style='color:red;'>❌ Merci de remplir tous les champs obligatoires.</p>";
    exit;
}

$message = "Nom : $name\nEmail : $email\nSujet : $subject\nMessage : $message_content";

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'mougellucas01@gmail.com';
    $mail->Password   = 'zkoe gckq khti wnif'; // ton mot de passe d'application Gmail
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('mougellucas01@gmail.com', 'Tennis Club Nantua');
    $mail->addAddress($destinataire);
    $mail->addReplyTo($email);

    $mail->isHTML(false);
    $mail->Subject = $subject;
    $mail->Body    = $message;

    $mail->send();
    echo "<p style='color:green;'>✅ Formulaire bien envoyé !</p>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erreur lors de l'envoi : {$mail->ErrorInfo}</p>";
}
?>

