<?php
session_start();

$upload_dir = __DIR__ . "/uploads";
$users_file = __DIR__ . "/users.json";

// Créer le dossier uploads si inexistant
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// --- LOGIN ---
if (!isset($_SESSION['user'])) {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $users = json_decode(file_get_contents($users_file), true);
        $found = false;
        foreach ($users as $u) {
            if ($u['username'] === $_POST['username'] && password_verify($_POST['password'], $u['password'])) {
                $_SESSION['user'] = $u['username'];
                $found = true;
                break;
            }
        }
        if (!$found) {
            $error = "Nom d'utilisateur ou mot de passe incorrect.";
        }
    }

    if (!isset($_SESSION['user'])) {
        echo '<!DOCTYPE html><html lang="fr"><head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Connexion - Dépôt de fichiers</tit
